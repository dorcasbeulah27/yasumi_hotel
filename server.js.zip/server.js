const express = require("express");

const app = express();
const dbConfig = require("./db");
const roomsRoute = require("./routes/roomsRoute");

app.use(express.json()); // Move this line up

app.use("/api/rooms", roomsRoute);

const port = process.env.PORT || 5000;
app.listen(port, () => console.log("server running on the port"));
