import React from "react";

export default function Navbar() {
  return (
    <div>
      <nav className="navbar navbar-expand-md navbar-dark bg-dark">
        <div className="container">
          <a
            className="navbar-brand d-md-none d-xs-block py-3"
            href="/location"
          >
            <img src="" height="40" alt="Company Logo" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item">
                <a
                  className="nav-link mx-2  btn rounded-0 btn-danger"
                  aria-current="page"
                  href="/home"
                >
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link mx-2 btn rounded-0 btn-danger"
                  href="/location"
                >
                  Location
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link mx-2 btn rounded-0 btn-danger"
                  href="/about"
                >
                  about
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link mx-2  btn rounded-0 btn-danger"
                  href="/catering"
                >
                  Catering
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link mx-2 btn rounded-0 btn-danger"
                  href="/signon"
                >
                  Sign-on
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link mx-2 btn rounded-0 btn-danger"
                  href="/sign-in"
                >
                  Sign-In
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div className="text-center p-3 d-none d-md-block">
        <img
          src="https://i.ytimg.com/vi/I8i2GPHT3VI/maxresdefault.jpg"
          height="120"
          alt="Company Logo"
        />
      </div>
    </div>
  );
}
