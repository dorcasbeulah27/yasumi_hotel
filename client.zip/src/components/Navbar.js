import React from "react";

export default function Navbar({ user }) {
  function logout() {
    localStorage.removeItem("currentUser");
    window.location.href = "/login";
  }

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark p-0">
        <div
          className="container-fluid"
          style={{ backgroundColor: "black", color: "#3B71FE" }}
        >
          <a className="navbar-brand" href="/home">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShuM7ESCj6yY1FzgZ_8zssOPjureYj1Qgvaqt3g9CnQHq5zRUC-MEZQ6ZLRglVP51yx-M&usqp=CAU"
              alt="i"
            ></img>
          </a>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div
            className="collapse navbar-collapse justify-content-center"
            id="navbarNavDropdown"
          >
            <ul className="navbar-nav">
              <li className="nav-item">
                <a className="nav-link mx-4" href="/home">
                  Home
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link mx-4" href="/loction">
                  Location
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link mx-4" href="/about">
                  About
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link mx-4" href="/services">
                  Services
                </a>
              </li>
            </ul>
          </div>

          <div className="ml-auto">
            {" "}
            {/* Apply ml-auto class here */}
            <ul className="navbar-nav">
              {!user ? (
                <>
                  <li className="nav-item">
                    <a className="nav-link" href="/login">
                      <button
                        className="btn-lg rounded-lg"
                        style={{
                          marginTop: "-20px",
                          fontWeight: "600",

                          color: "white",
                          backgroundColor: "black",
                        }}
                      >
                        Login
                      </button>
                    </a>
                  </li>

                  <li className="nav-item">
                    <a className="nav-link mx-2" href="/register">
                      <button
                        className="btn-lg"
                        style={{
                          marginTop: "-20px",
                          fontWeight: "600",
                          border: "none",
                          marginRight: "5px",
                          color: "white",
                          backgroundColor: "#3B71FE",
                        }}
                      >
                        Create Account
                      </button>
                    </a>
                  </li>
                </>
              ) : (
                <li className="nav-item dropdown">
                  <div className="nav-link">
                    <button
                      className="btn btn-secondary dropdown-toggle"
                      type="button"
                      data-toggle="dropdown"
                      aria-expanded="false"
                    >
                      <i className="fa fa-user"></i> {user.name}
                    </button>
                    <div className="dropdown-menu">
                      <a className="dropdown-item" href="/profile">
                        Profile
                      </a>
                      <a className="dropdown-item" href="" onClick={logout}>
                        LogOut
                      </a>
                    </div>
                  </div>
                </li>
              )}
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
}
