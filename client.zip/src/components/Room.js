import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Carousel from "react-bootstrap/Carousel";
import { Link } from "react-router-dom";

function Room({ room }) {
  const [modalShow, setModalShow] = React.useState(false);

  function MyVerticallyCenteredModal(props) {
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            {room.name}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Carousel fade>
            {room.imageURLS.map((url) => {
              return (
                <Carousel.Item key={url}>
                  <img className="d-block w-100 bigimg" src={url} alt="" />
                  <Carousel.Caption>{room.description}</Carousel.Caption>
                </Carousel.Item>
              );
            })}
          </Carousel>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  return (
    <div className="row bs">
      <div className="col-md-4">
        <img src={room.imageURLS[0]} alt={""} className="smallimg" />
      </div>

      <div className="col-md-7">
        <b>
          <br />
          <h1>HOTEL NAME:{room.name}</h1>
          <p>RENT:{room.rentPerDay}</p>
          <p>MAX COUNT:{room.maxCount}</p>
          <p>PHOME NUMBER:{room.phoneNumber}</p>
          <p>ROOM TYPE:{room.roomType}</p>
          <p>REVIEWS:{room.reviews}</p>
        </b>

        <div style={{ float: "right" }}>
          <Link to={`/book/${room._id}`}>
            <button className="btn btn-primary btn-lg">Book Now</button>
          </Link>
          <button
            className="btn btn-primary btn-lg "
            onClick={() => setModalShow(true)}
          >
            View Details
          </button>
        </div>
      </div>

      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    </div>
  );
}

export default Room;
