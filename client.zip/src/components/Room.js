import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Carousel from "react-bootstrap/Carousel";
import { Link } from "react-router-dom";

function Room({ room, fromdate, todate }) {
  const [modalShow, setModalShow] = React.useState(false);

  function MyVerticallyCenteredModal(props) {
    return (
      <Modal {...props} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{room.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Carousel fade>
            {room.ImageURL.map((url) => {
              return (
                <Carousel.Item key={url}>
                  <img src={url} alt="" />
                  <Carousel.Caption>{room.Description}</Carousel.Caption>
                </Carousel.Item>
              );
            })}
          </Carousel>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    );
  }

  return (
    <div className="mt-3">
      <img src={room.ImageURL[0]} alt={""} className="smallimg" />

      <div>
        <b>
          <br />
          <h1>HOTEL NAME: {room.name}</h1>
          <p>ROOM NUMBER: {room.RoomNumber}</p>
          <p>RENT: {room.PricePerNightight}</p>
          <p>MAX COUNT: {room.MaxCapacity}</p>
          <p>PHONE NUMBER: {room.PhoneNumber}</p>
          <p>ROOM TYPE: {room.RoomType}</p>
        </b>
        <div>
          {fromdate && todate && (
            <Link to={`/book/${room._id}/${fromdate}/${todate}`}>
              <Button className="btn-lg">Book Now</Button>
            </Link>
          )}

          <button className="btn-lg" onClick={() => setModalShow(true)}>
            View Details
          </button>
        </div>
      </div>

      <MyVerticallyCenteredModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
    </div>
  );
}

export default Room;
