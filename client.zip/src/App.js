import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Homescreen from "./screens/Homescreen";
import Bookingscreen from "./screens/Bookingscreen";

function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path="/home" element={<Homescreen />} />
        <Route path="/book/:roomid" element={<Bookingscreen />} />
      </Routes>
    </div>
  );
}

export default App;
