import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Homescreen from "./screens/Homescreen";
import Bookingscreen from "./screens/Bookingscreen";
import Registerscreen from "./screens/ Registerscreen";
import Loginscreen from "./screens/Loginscreen";
import Profilescreen from "./screens/Profilescreen";
import Adminscreen from "./screens/Adminscreen";
import Landingscreens from "./screens/Landingscreens";

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("currentUser"));
    if (storedUser) {
      setUser(storedUser);
    }
  }, []);
  return (
    <div className="app-background">
      <div className="bg-image">
        <div className="App">
          <Navbar user={user} />

          <Routes>
            <Route path="/home" element={<Homescreen />} />
            <Route
              path="/book/:roomid/:fromdate/:todate"
              element={<Bookingscreen />}
            />

            <Route path="/register" element={<Registerscreen />} />
            <Route path="/login" element={<Loginscreen />} />
            <Route path="/profile" element={<Profilescreen />} />
            <Route path="/admin" element={<Adminscreen />} />
            <Route path="/" element={<Landingscreens />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}

export default App;
