import React, { useState, useEffect } from "react";
import axios from "axios";
import { Tabs } from "antd";
import Loader from "../components/Loader";
import Error from "../components/Error";
import Swal from "sweetalert2";
import { Divider, Space, Tag } from "antd";
const { TabPane } = Tabs;

export default function Profilescreen() {
  const user = JSON.parse(localStorage.getItem("currentUser"));

  useEffect(() => {
    if (!user) {
      window.location.href = "/login";
    }
  }, []);

  return (
    <div>
      <Tabs defaultActiveKey="1">
        <TabPane tab="PROFILE" key="1">
          <h1>
            <b>MY PROFILE</b>
          </h1>

          <div className="bkd">
            <p>NAME: {user.name}</p>
            <p>EMAIL: {user.email}</p>
            <p>isAdmin: {user.isAdmin ? "YES" : "NO"}</p>
          </div>
        </TabPane>
        <TabPane tab="MY BOOKINGS" key="2">
          <MyBookings user={user} />
        </TabPane>
      </Tabs>
    </div>
  );
}

export function MyBookings({ user }) {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        setLoading(true);
        const response = await axios.post("/api/bookings/getbookingsbyuserid", {
          userid: user._id,
        });
        setBookings(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        setLoading(false);
        setError(error);
      }
    };

    fetchBookings();
  }, [user]);

  const cancelBooking = async (bookingid, roomid) => {
    try {
      setLoading(true);
      const result = await axios.post("/api/bookings/cancelbooking", {
        bookingid,
        roomid,
      });
      console.log(result.data); // Logging the response data
      setLoading(false);
      Swal.fire("Congrates", " Your Room Has Been Cancelled", "success").then(
        (result) => {
          window.location.reload();
        }
      );
    } catch (error) {
      console.error("Error cancelling booking:", error);
      setLoading(false);
      setError(error);
      Swal.fire("Huh", "Something Went Wrong", "error");
    }
  };

  return (
    <div className="bkd">
      {loading && <Loader />}
      {error && <Error message={error.message} />}

      <ul>
        {bookings.map((booking) => (
          <li key={booking._id}>
            <div>
              <h2>
                <b>Room: {booking.room}</b>
              </h2>
            </div>

            <p>
              <b>From:</b> {booking.fromdate}
            </p>
            <p>
              <b>To:</b> {booking.todate}
            </p>

            <p>
              <b>Total Amount: </b>
              {booking.totalamount}
            </p>

            <p>
              <b>Total Days:</b> {booking.totaldays}
            </p>

            <p>
              <b>Transaction ID:</b> {booking.transactionId}
            </p>

            <p>
              <b>Status: </b>
              {booking.status === "cancelled" ? (
                <Tag className="bkd" color="red">
                  CANCELLED
                </Tag>
              ) : (
                <Tag className="bkd" color="green">
                  CONFIRMED
                </Tag>
              )}
            </p>

            {booking.status !== "cancelled" && (
              <div className="text-">
                <button
                  className="btn btn-primary "
                  onClick={() => {
                    cancelBooking(booking._id, booking.roomid);
                  }}
                >
                  CANCEL BOOKING
                </button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
