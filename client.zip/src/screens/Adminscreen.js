import React, { useEffect, useState } from "react";
import axios from "axios";
import { Tabs } from "antd";
import Loader from "../components/Loader";
import Error from "../components/Error";
import Swal from "sweetalert2";

const { TabPane } = Tabs;
function Adminscreen() {
  useEffect(() => {
    if (!JSON.parse(localStorage.getItem("currentUser")).isAdmin) {
      window.location.href = "/home";
    }
  });
  return (
    <div className="mt-3 mt-3 mr-3">
      <h2 className="text-center" style={{ fontSize: "30px" }}>
        Admin Panel
      </h2>
      <Tabs defaultActiveKey="1">
        <TabPane tab="Bookings" key="1">
          <Bookings />
        </TabPane>
        <TabPane tab="Rooms" key="2">
          <Rooms />
        </TabPane>
        <TabPane tab="Add Rooms" key="3">
          <Addroom />
        </TabPane>
        <TabPane tab="Users" key="4">
          <Users />
        </TabPane>
      </Tabs>
    </div>
  );
}
export default Adminscreen;

export function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get("/api/bookings/getallbookings");
        setBookings(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        setLoading(false);
        setError(error);
      }
    };

    fetchBookings();
  }, []);

  return (
    <div className="row">
      <div className="col-md-10">
        <h1>BOOKINGS</h1>
        {loading && <Loader />}
        {error && <Error message="Failed to fetch bookings." />}
        <table className="table table-bordered table-dark table-hover">
          <thead>
            <tr>
              <th>Booking Id</th>
              <th>User Id</th>
              <th>Room</th>
              <th>From</th>
              <th>To</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>
            {bookings.length > 0 &&
              bookings.map((booking) => {
                return (
                  <tr key={booking._id}>
                    <td>{booking._id}</td>
                    <td>{booking.userid}</td>
                    <td>{booking.room}</td>
                    <td>{booking.fromdate}</td>
                    <td>{booking.todate}</td>
                    <td>{booking.status}</td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export function Rooms() {
  const [rooms, setRooms] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const response = await axios.get("/api/rooms/getallrooms");
        setRooms(response.data.rooms); // Access the 'rooms' property from the response data
        setLoading(false);
      } catch (error) {
        console.error("Error fetching rooms:", error);
        setLoading(false);
        setError(error);
      }
    };

    fetchRooms();
  }, []);

  return (
    <div className="row">
      <div className="col-md-10">
        <h1>ROOMS</h1>
        {loading && <Loader />}
        {error && <Error message="Failed to fetch rooms." />}

        <table className="table table-bordered table-dark table-hover mx-auto">
          <thead>
            <tr>
              <th>Room Id</th>
              <th>Name</th>
              <th>Type</th>
              <th>Rent Per Day</th>
              <th>Max Count</th>
              <th>Phone Number</th>
            </tr>
          </thead>
          <tbody>
            {rooms.length > 0 &&
              rooms.map((room) => {
                return (
                  <tr key={room._id}>
                    <td>{room._id}</td>
                    <td>{room.name}</td>
                    <td>{room.RoomType}</td>
                    <td>{room.PricePerNightight}</td>
                    <td>{room.MaxCapacity}</td>
                    <td>{room.PhoneNumber}</td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export function Users() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get("/api/users/getallusers");
        setUsers(response.data); // Corrected to access response.data directly
        setLoading(false);
      } catch (error) {
        console.error("Error fetching users:", error);
        setLoading(false);
        setError(error);
      }
    };

    fetchUsers();
  }, []);

  return (
    <div className="row">
      <div className="col-md-10">
        <h1>USERS</h1>
        {loading && <Loader />}
        {error && <Error message="Failed to fetch users." />}
        <table className="table table-bordered table-dark table-hover mx-auto">
          <thead>
            <tr>
              <th>User Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Is Admin</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user._id}>
                <td>{user._id}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.isAdmin ? "Yes" : "No"}</td>{" "}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Addroom() {
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [PricePerNightight, setPricePerNightight] = useState();
  const [MaxCapacity, setMaxCapacity] = useState();
  const [Description, setDescription] = useState();
  const [PhoneNumber, setPhoneNumber] = useState();
  const [RoomType, setRoomtype] = useState("");
  const [img1, setImg1] = useState();
  const [img2, setImg2] = useState();
  const [img3, setImg3] = useState();

  async function addroom() {
    const newRoom = {
      name,
      PricePerNightight,
      MaxCapacity,
      Description,

      PhoneNumber,
      RoomType,
      ImageURL: [img1, img2, img3],
    };
    try {
      setLoading(true);
      const result = await (
        await axios.post("/api/rooms/addroom", newRoom)
      ).data;
      console.log(result);
      setLoading(false);
      Swal.fire(
        "CONGRATS",
        " YOUR NEW ROOM ADDED SUCCESSFULLY",
        "success"
      ).then((result) => {
        window.location.href = "/home";
      });
    } catch (error) {
      console.log(error);
      setLoading(false);
      Swal.fire("OOPS", " SOMETHING WENT WRONG..TRY AGAIN LATER", "error");
    }
  }

  return (
    <div className="row">
      <div className="col-md-5" style={{ height: "40px" }}>
        {loading && <Loader />}
        <input
          RoomType="text"
          placeholder="Room Name"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
          }}
        />
        <input
          type="text"
          placeholder="Rent Per Day "
          value={PricePerNightight}
          onChange={(e) => {
            setPricePerNightight(e.target.value);
          }}
        />
        <input
          type="text"
          placeholder="Max Capacity"
          value={MaxCapacity}
          onChange={(e) => {
            setMaxCapacity(e.target.value);
          }}
        />
        <input
          type="text"
          placeholder="Description"
          value={Description}
          onChange={(e) => {
            setDescription(e.target.value);
          }}
        />
        <input
          type="text"
          placeholder="Phone Number"
          value={PhoneNumber}
          onChange={(e) => {
            setPhoneNumber(e.target.value);
          }}
        />

        <div className="col-md-5" style={{ height: "40px" }}>
          <input
            type="text"
            placeholder="Type"
            value={RoomType}
            onChange={(e) => {
              setRoomtype(e.target.value);
            }}
          />
          <input
            type="text"
            placeholder="Image Url 1"
            value={img1}
            onChange={(e) => {
              setImg1(e.target.value);
            }}
          />
          <input
            type="text"
            placeholder="Image Url 2"
            value={img2}
            onChange={(e) => {
              setImg2(e.target.value);
            }}
          />
          <input
            type="text"
            placeholder="Image Url 3"
            value={img3}
            onChange={(e) => {
              setImg3(e.target.value);
            }}
          />
        </div>

        <div className="text-right">
          <button className="btn-lg" onClick={addroom}>
            Add Rooms
          </button>
        </div>
      </div>
    </div>
  );
}
