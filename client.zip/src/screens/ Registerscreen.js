import React, { useState } from "react";
import axios from "axios";
import Loader from "../components/Loader";
import Error from "../components/Error";
import Success from "../components/Success";

function Registerscreen() {
  const [name, setname] = useState("");
  const [email, setemail] = useState("");
  const [pass, setpass] = useState("");
  const [cpass, setcpass] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();
  const [success, setSuccess] = useState();

  async function register() {
    if (pass === cpass) {
      const user = {
        name,
        email,
        pass,
        cpass,
      };
      try {
        setLoading(true);
        const result = await axios.post("/api/users/register", user);
        console.log("registration successfull", result.data);
        setLoading(false);
        setSuccess(true);

        setname("");
        setemail("");
        setpass("");
        setcpass("");
      } catch (error) {
        console.error("Registration failed:", error);
        setLoading(false);
        setError(true);
      }
    } else {
      alert("Password is not matching");
    }
  }

  return (
    <div>
      {loading && <Loader />}
      {error && <Error />}

      <div className="row justify-content-center mt-5">
        <div className="col-md-5">
          <div>
            {success && <Success message="Registration success" />}
            <h1>Register</h1>

            <input
              type="text"
              className="form-control"
              placeholder="Name"
              value={name}
              onChange={(e) => setname(e.target.value)}
            />

            <input
              type="email"
              className="form-control"
              placeholder="Email"
              value={email}
              onChange={(e) => setemail(e.target.value)}
            />

            <input
              type="password" // Change input type to password
              className="form-control"
              placeholder="Password"
              value={pass}
              onChange={(e) => setpass(e.target.value)}
            />

            <input
              type="password" // Change input type to password
              className="form-control"
              placeholder="Confirm Password"
              value={cpass}
              onChange={(e) => setcpass(e.target.value)}
            />

            <button className="btn-lg" onClick={register}>
              Register
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Registerscreen;
