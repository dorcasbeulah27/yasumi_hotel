import React from "react";
import { Link } from "react-router-dom";
import "animate.css/animate.min.css";

export default function Landingscreens() {
  return (
    <div className="row landing justify-content-center">
      <div className="col-md-8 text-center animate__animated animate__zoomIn">
        <h2 style={{ color: "white", fontSize: "130px" }}>YASUMI ROOMS</h2>
        <h1 style={{ color: "white" }}> A place to relax and be yourself</h1>
        <Link to="/home">
          <button
            className="btn-lg"
            style={{
              fontWeight: "600",
              border: "none",
              color: "white",
              backgroundColor: "#3B71FE",
              marginTop: "20px",
            }}
          >
            Get Started
          </button>
        </Link>
      </div>
    </div>
  );
}
