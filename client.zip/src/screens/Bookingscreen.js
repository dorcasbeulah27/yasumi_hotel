import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

function Bookingscreen() {
  const { roomid } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [room, setRoom] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.post("/api/rooms/getroombyid", {
          roomid: roomid,
        });

        console.log("API Response:", response.data);
        setRoom(response.data.rooms); // Assuming response.data.rooms is a single room object
        setLoading(false);
      } catch (error) {
        setError(error.message);
        console.error(error);
        setLoading(false);
      }
    };

    fetchData();
  }, [roomid]); // Added roomid as a dependency for useEffect

  return (
    <div>
      {loading ? (
        <h1>Loading...</h1>
      ) : error ? (
        <h1>Error...</h1>
      ) : (
        <div className="row">
          <div className="col-md-5"></div>
          <div className="col-md-5">
            <h1>{room.name}</h1>
            <img src={room.imageURLS[0]} className="bigimg" alt={room.name} />
          </div>
        </div>
      )}
    </div>
  );
}

export default Bookingscreen;
