import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Loader from "../components/Loader";
import Error from "../components/Error";
import moment from "moment";
import StripeCheckout from "react-stripe-checkout";
import Swal from "sweetalert2";

function Bookingscreen() {
  const { roomid, fromdate, todate } = useParams();
  const [loading, setLoading] = useState(true);
  const [room, setRoom] = useState(null);
  const [totalamount, setTotalamount] = useState(null);
  const [error, setError] = useState(null);

  const fdate = moment(fromdate, "YYYY-MM-DD");
  const tdate = moment(todate, "YYYY-MM-DD");
  const totaldays = moment.duration(tdate.diff(fdate)).asDays() + 1;

  useEffect(() => {
    if (!localStorage.getItem("currentUser")) {
      window.location.href = "/login";
    }
    async function fetchData() {
      try {
        setLoading(true);
        const response = await axios.get(`/api/rooms/getroombyid/${roomid}`);
        setRoom(response.data.room);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching room data:", error);
        setError("Error fetching room data. Please try again later.");
        setLoading(false);
      }
    }
    fetchData();
  }, [roomid]);

  useEffect(() => {
    if (room) {
      const calculatedTotalAmount = room.PricePerNightight * totaldays;
      setTotalamount(calculatedTotalAmount);
    }
  }, [room, totaldays]);

  async function bookRoom(token) {
    try {
      const currentUser = JSON.parse(localStorage.getItem("currentUser"));
      if (!currentUser) {
        throw new Error("User not found in localStorage");
      }

      if (!room) {
        throw new Error("Room details not found");
      }

      const bookingDetails = {
        room: room,
        userid: currentUser._id,
        fromdate: fromdate,
        todate: todate,
        totalamount: totalamount,
        totaldays: totaldays,
        token: token,
      };
      try {
        setLoading(true);
        // Store booking details in localStorage as a fallback
        localStorage.setItem("bookingDetails", JSON.stringify(bookingDetails));
        setLoading(false);
        Swal.fire("CONGRATS", " YOUR ROOM BOOKED SUCCESSFULLY", "success").then(
          (response) => {
            window.location.href = "/bookings";
          }
        );
      } catch (error) {
        setLoading(false);
        Swal.fire("DAMMM!!!", " SOMETHING WENT WRONG", "error");
      }
      // Send booking request to server
      const response = await axios.post(
        "/api/bookings/bookroom",
        bookingDetails
      );
      console.log("Booking response:", response.data);

      // After successful booking, update the state or perform any other necessary actions
      // For example, you can clear the localStorage:
      localStorage.removeItem("bookingDetails");
    } catch (error) {
      console.error("Error booking room:", error);
    }
  }
  async function onToken(token) {
    console.log("Token:", token);
    await bookRoom(token);
  }

  return (
    <div>
      {loading ? (
        <Loader />
      ) : room ? (
        <div>
          <h1>{room.name}</h1>
          <img src={room.ImageURL[0]} className="bigimg" alt={room.name} />
          <div style={{ display: "flex" }}>
            <b>
              <h1>Booking details</h1>
              <hr />
              <p>
                Name:{" "}
                {localStorage.getItem("currentUser") &&
                  JSON.parse(localStorage.getItem("currentUser")).name}
              </p>
              <p>From Date: {fromdate}</p>
              <p>To Date: {todate}</p>
              <p>Max. Capacity: {room.MaxCapacity}</p>
              <h1>Amount: {totalamount}</h1>
              <hr />
              <p>Total Days: {totaldays}</p>

              <p>Rent per Night: {room.PricePerNightight}</p>
              <div>
                <StripeCheckout
                  amount={totalamount * 100} // Stripe expects amount in cents
                  currency="INR"
                  stripeKey="pk_test_51OlDORSHLWsqRQ6kq8xYAklHpQXuZ33WAqcwvo5zozmbLjqU1pYxcmJXCbC82BKpsvfAwPlrhC9h3padzVpJuGmX00VcIc907g"
                  email={room.email}
                  name="Room Booking"
                  description="Room booking payment"
                  token={onToken}
                >
                  <button className="btn-lg">Pay now</button>
                </StripeCheckout>
              </div>
            </b>
          </div>
        </div>
      ) : (
        <Error message={error} />
      )}
    </div>
  );
}

export default Bookingscreen;
