import React, { useState, useEffect } from "react";
import axios from "axios";
import Room from "../components/Room";
import Loader from "../components/Loader";
import "./Homescreen.css";
import { DatePicker } from "antd";
import moment from "moment";
const { RangePicker } = DatePicker;

function Homescreen() {
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [fromdate, setFromdate] = useState();
  const [todate, setTodate] = useState();
  const [duplicaterooms, setDuplicaterooms] = useState([]);
  const [type, setType] = useState("all");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("/api/rooms/getallrooms");
        console.log("API Response:", response.data);

        setRooms(response.data.rooms);
        setDuplicaterooms(response.data.rooms);
        setLoading(false);
      } catch (error) {
        console.error(error);
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  function filterByDate(dates, dateStrings) {
    console.log("Raw Dates:", dates);
    console.log("Date Strings:", dateStrings);

    if (dates && dates.length === 2) {
      const fromDateStr = moment(dateStrings[0]).format("YYYY-MM-DD");
      const toDateStr = moment(dateStrings[1]).format("YYYY-MM-DD");

      const filteredRooms = duplicaterooms.filter((room) => {
        const isAvailable = room.currentBookings.every((booking) => {
          const bookingFromDate = moment(booking.fromdate, "DD-MM-YY").format(
            "YYYY-MM-DD"
          );
          const bookingToDate = moment(booking.todate, "DD-MM-YY").format(
            "YYYY-MM-DD"
          );
          return (
            fromDateStr < bookingFromDate ||
            fromDateStr > bookingToDate ||
            toDateStr < bookingFromDate ||
            toDateStr > bookingToDate
          );
        });
        return isAvailable;
      });

      setRooms(filteredRooms);
      setFromdate(fromDateStr);
      setTodate(toDateStr);
    }
  }

  function filterByType(selectedType) {
    const typeToFilter = selectedType.toLowerCase();

    const filteredRooms = duplicaterooms.filter((room) => {
      if (typeToFilter === "all") return true;
      return room.RoomType && room.RoomType.toLowerCase() === typeToFilter;
    });

    setRooms(filteredRooms);
    setType(selectedType);
  }

  return (
    <div className="container">
      <div className="row mt-5 bs">
        <div className="col-md-6">
          <RangePicker
            className="custom-datepicker"
            format="YYYY-MM-DD"
            onChange={filterByDate}
            style={{ width: "100%", height: "75px", fontSize: "16px" }}
          />
        </div>

        <div className="col-md-6">
          <select
            value={type}
            onChange={(e) => {
              const selectedType = e.target.value;
              filterByType(selectedType); // Pass the selected value directly
            }}
            style={{ width: "100%", height: "50px", fontSize: "16px" }}
          >
            <option value="delux">Delux</option>
            <option value="all" onClick={() => filterByType("all")}>
              All
            </option>
            <option value="luxary">Luxary</option>
          </select>
        </div>
      </div>
      <div className="mt-5">
        {loading ? (
          <Loader />
        ) : (
          rooms.map((room) => (
            <div key={room.name}>
              <Room room={room} fromdate={fromdate} todate={todate} />
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Homescreen;
