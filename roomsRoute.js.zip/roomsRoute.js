const express = require("express");
const router = express.Router();
const room = require("../models/room");

router.get("/getallrooms", async (reg, res) => {
  try {
    const rooms = await room.find({});
    return res.send({ rooms });
  } catch (error) {
    return res.status(400), express.json({ message: error });
  }
});

router.post("/getroombyid", async (req, res) => {
  const roomid = req.body.roomid;
  try {
    const rooms = await room.findOne({ _id: roomid });
    return res.send({ rooms });
  } catch (error) {
    return res.status(400).json({ message: error });
  }
});
module.exports = router;
