const mongoose = require("mongoose");

const roomSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    MaxCapacity: {
      type: Number,
      required: true,
    },
    PhoneNumber: {
      type: Number,
      required: true,
    },
    PricePerNightight: {
      type: Number,
      required: true,
    },
    ImageURL: [
      {
        type: String,
        required: true,
      },
    ],
    currentBookings: [
      {
        bookingid: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Booking", // Reference to the Booking model
          required: true,
        },
        fromdate: Date, // Consider using Date type for dates
        todate: Date, // Consider using Date type for dates
        userid: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
        },
        status: String,
      },
    ],
    RoomType: {
      type: String,
      required: true,
    },
    Description: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);
const roomModel = mongoose.model("rooms", roomSchema);
module.exports = roomModel;
