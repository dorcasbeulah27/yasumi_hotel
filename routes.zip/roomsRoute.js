const express = require("express");
const router = express.Router();
const Room = require("../models/room");

// Route to fetch all rooms
router.get("/getallrooms", async (req, res) => {
  try {
    const rooms = await Room.find({});
    return res.send({ rooms });
  } catch (error) {
    return res.status(400).json({ message: error });
  }
});

// Route to fetch a room by its ID
router.get("/getroombyid/:roomid", async (req, res) => {
  const roomid = req.params.roomid;
  try {
    const room = await Room.findOne({ _id: roomid });
    return res.json({ room });
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
});

// Route to add a new room
router.post("/addroom", async (req, res) => {
  try {
    const newRoom = new Room(req.body);
    await newRoom.save();
    res.send("New room added successfully");
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
});

module.exports = router;
